# Stock-Market-Prediction

## Stock Market Prediction using Numerical and Textual Analysis

This project talks about how we can use the ARIMA model to forecast stock prices in Python and how to use VADER to predict the Sentiments of news headlines.  

To try this project:

Download historical stock prices from finance.yahoo.com

Download textual (news) data from https://bit.ly/36fFPI6

